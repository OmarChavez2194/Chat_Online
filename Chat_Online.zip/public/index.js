const path = require('path'); // Importa el módulo 'path' para trabajar con rutas de archivos y directorios
const express = require('express'); // Importa el módulo 'express' para crear aplicaciones web
const app = express(); // Crea una instancia de una aplicación Express
const SocketIO = require('socket.io'); // Importa el módulo 'socket.io' para agregar funcionalidades de WebSocket a la aplicación

// Ruta para servir "login.html" en la raíz
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'login.html')); // Envía el archivo 'login.html' como respuesta cuando se accede a la raíz del sitio
});

// Configuración de la carpeta "public" como directorio de archivos estáticos
app.use(express.static(path.join(__dirname, 'public'))); // Define la carpeta 'public' como la ubicación de los archivos estáticos que pueden ser accedidos directamente

// Establecer el puerto del servidor
app.set('port', process.env.PORT || 3000); // Establece el puerto del servidor a un valor definido en el entorno o al 3000 por defecto

// Iniciar el servidor
const server = app.listen(app.get('port'), () => {
    console.log('Server port:', app.get('port')); // Inicia el servidor y escucha en el puerto especificado, luego imprime el puerto en la consola
});

// Configuración de Socket.IO
const io = SocketIO(server); // Inicializa Socket.IO utilizando el servidor HTTP creado

// Función para generar un color aleatorio
function getRandomColor() {
    const letters = '0123456789ABCDEF'; // Define los caracteres hexadecimales para los colores
    let color = '#'; // Inicia la cadena del color con '#'
    for (let i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)]; // Añade 6 caracteres hexadecimales aleatorios para formar un color
    }
    return color; // Devuelve el color generado
}

const users = {}; // Crea un objeto para almacenar los usuarios y sus colores

io.on('connection', (socket) => {
    let username = ''; // Variable para almacenar el nombre de usuario
    let userColor = ''; // Variable para almacenar el color del usuario

    socket.on('join', (data) => {
        username = data.username; // Asigna el nombre de usuario recibido del cliente
        userColor = getRandomColor(); // Genera un color aleatorio para el usuario
        users[username] = userColor; // Almacena el color del usuario en el objeto 'users'
        console.log(`${username} joined the chat with color ${userColor}`); // Imprime en la consola que el usuario se unió al chat con su color
    });

    socket.on('message', (data) => {
        const userColor = users[data.username]; // Obtiene el color del usuario que envía el mensaje
        socket.broadcast.emit('message', { username: data.username, msg: data.msg, color: userColor }); // Envía el mensaje a todos los clientes conectados excepto al que lo envía
    });

    socket.on('disconnect', () => {
        delete users[username]; // Elimina al usuario del objeto 'users' cuando se desconecta
        console.log(`${username} left the chat`); // Imprime en la consola que el usuario dejó el chat
    });
});
